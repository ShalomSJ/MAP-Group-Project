package com.example.teamregistration.ui.theme

import com.example.teamregistration.viewModel.TeamRegistrationViewModel



import androidx.compose.runtime.Composable
import androidx.lifecycle.viewmodel.compose.viewModel


@Composable
fun TeamRegistrationScreen() {
    val viewModel: TeamRegistrationViewModel = viewModel()
    TeamRegistrationForm(viewModel)
}
