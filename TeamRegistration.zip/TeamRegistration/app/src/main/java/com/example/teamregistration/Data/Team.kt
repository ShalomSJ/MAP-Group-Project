package com.example.teamregistration.Data



data class Team(
    val teamName: String = "",
    val selectedCategory: String = "",
    val contactPerson: String = "",
    val email: String = "",
    val phoneNumber: String = ""
)