package com.example.teamregistration.viewModel

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.ViewModel
import com.example.teamregistration.Data.FirebaseRepository
import com.example.teamregistration.Data.Team
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.launch

class TeamRegistrationViewModel : ViewModel() {
    private val repository = FirebaseRepository()
    var teamName by mutableStateOf("")
    var selectedCategory by mutableStateOf("")
    var contactPerson by mutableStateOf("")
    var email by mutableStateOf("")
    var phoneNumber by mutableStateOf("")

    fun registerTeam() {
       println("Team Registered!")
    }
}
