package com.example.teamregistration




import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import com.example.teamregistration.ui.theme.TeamRegistrationForm
import com.example.teamregistration.ui.theme.TeamRegistrationTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            TeamRegistrationTheme {
                TeamRegistrationForm()
            }
        }
    }
}