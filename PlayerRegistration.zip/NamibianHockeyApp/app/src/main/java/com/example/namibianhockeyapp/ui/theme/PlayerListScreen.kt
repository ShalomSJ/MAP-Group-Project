package com.example.namibianhockeyapp.ui.theme


import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.clickable
import androidx.compose.foundation.lazy.items
import androidx.compose.runtime.collectAsState
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.namibianhockeyapp.viewModel.PlayerViewModel

@Composable
fun PlayerListScreen(navController: NavController, playerViewModel: PlayerViewModel) {
    val players by playerViewModel.players.collectAsStateWithLifecycle()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Text("Registered Players", style = MaterialTheme.typography.titleLarge)
        Spacer(Modifier.height(16.dp))

        LazyColumn(
            modifier = Modifier.weight(1f)
        ) {
            items(players) { player ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp)
                        .clickable { navController.navigate("detail/${player.idNumber}") },
                    elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text("Name: ${player.fullName}")
                        Text("DOB: ${player.dateOfBirth}")
                        Text("Gender: ${player.gender}")
                        Text("ID: ${player.idNumber}")
                        Text("Nationality: ${player.nationality}")
                        Text("Position: ${player.position}")
                        Text("Team: ${player.team}")
                        Text("Email: ${player.email}")
                        Text("Phone: ${player.contactNumber}")
                    }
                }
            }
        }

        Spacer(Modifier.height(16.dp))
        Button(
            onClick = { navController.navigate("register") },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Register New Player")
        }
    }
}