package com.example.namibianhockeyapp.Data

enum class PlayerStatus {
    PENDING,
    APPROVED,
    REJECTED
}