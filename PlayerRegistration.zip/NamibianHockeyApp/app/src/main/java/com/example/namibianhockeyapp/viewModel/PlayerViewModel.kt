package com.example.namibianhockeyapp.viewModel


import androidx.lifecycle.ViewModel
import com.example.namibianhockeyapp.Data.Player
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update



class PlayerViewModel : ViewModel() {
    private val _players = MutableStateFlow<List<Player>>(emptyList())
    val players = _players.asStateFlow()

    fun addPlayer(player: Player) {
        _players.update { currentPlayers ->
            currentPlayers + player
        }
    }

    fun updatePlayer(updatedPlayer: Player) {
        _players.update { currentPlayers ->
            currentPlayers.map { player ->
                if (player.id == updatedPlayer.id) updatedPlayer else player
            }
        }
    }

    fun deletePlayer(idNumber: String) {
        _players.update { currentPlayers ->
            currentPlayers.filterNot { it.id == idNumber }
        }
    }
}