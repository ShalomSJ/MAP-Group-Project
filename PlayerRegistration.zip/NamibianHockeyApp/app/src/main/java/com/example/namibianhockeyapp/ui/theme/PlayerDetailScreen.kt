package com.example.namibianhockeyapp.ui.theme

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.namibianhockeyapp.viewModel.PlayerViewModel

@Composable
fun PlayerDetailScreen(id: String, playerViewModel: PlayerViewModel, navController: NavController) {
    val players by playerViewModel.players.collectAsStateWithLifecycle()
    val player = players.find { it.idNumber == id }

    if (player != null) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp)
        ) {
            Column(
                modifier = Modifier.weight(1f)
            ) {
                Text("Player Details", style = MaterialTheme.typography.titleLarge)
                Spacer(Modifier.height(16.dp))

                Text("Name: ${player.fullName}")
                Text("DOB: ${player.dateOfBirth}")
                Text("Gender: ${player.gender}")
                Text("Nationality: ${player.nationality}")
                Text("ID Number: ${player.idNumber}")
                Text("Position: ${player.position}")
                Text("Team: ${player.team}")
                Text("Email: ${player.email}")
                Text("Contact: ${player.contactNumber}")
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Button(onClick = { navController.popBackStack() }) {
                    Text("Back")
                }

                Button(onClick = {
                    navController.navigate("register_edit/${player.idNumber}")
                }) {
                    Text("Edit")
                }

                Button(
                    onClick = {
                        playerViewModel.deletePlayer(player.idNumber)
                        navController.popBackStack()
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.error
                    )
                ) {
                    Text("Delete")
                }
            }
        }
    } else {
        Box(
            modifier = Modifier.fillMaxSize(),
            contentAlignment = Alignment.Center
        ) {
            Text("Player not found")
        }
    }
}