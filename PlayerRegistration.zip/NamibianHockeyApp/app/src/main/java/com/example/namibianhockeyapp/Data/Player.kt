package com.example.namibianhockeyapp.Data

import java.util.UUID


data class Player(
    val id: String = UUID.randomUUID().toString(),
    val fullName: String,
    val dateOfBirth: String,
    val gender: String,
    val nationality: String,
    val idNumber: String,
    val position: String,
    val team: String,
    val email: String,
    val contactNumber: String,
    val status: PlayerStatus = PlayerStatus.PENDING
) {

}