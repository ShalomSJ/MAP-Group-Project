package com.example.namibianhockeyapp

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.namibianhockeyapp.ui.theme.NamibianHockeyAppTheme
import com.example.namibianhockeyapp.ui.theme.PlayerDetailScreen
import com.example.namibianhockeyapp.ui.theme.PlayerListScreen
import com.example.namibianhockeyapp.ui.theme.RegisterPlayerScreen
import com.example.namibianhockeyapp.viewModel.PlayerViewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            NamibianHockeyAppTheme {
                val navController = rememberNavController()
                val playerViewModel: PlayerViewModel = viewModel()

                NavHost(
                    navController = navController,
                    startDestination = "list"
                ) {
                    composable("list") {
                        PlayerListScreen(navController, playerViewModel)
                    }
                    composable("register") {
                        RegisterPlayerScreen(navController, playerViewModel)
                    }
                    composable("detail/{playerId}") { backStackEntry ->
                        val playerId = backStackEntry.arguments?.getString("playerId") ?: ""
                        PlayerDetailScreen(playerId, playerViewModel, navController)
                    }
                    composable("register_edit/{id}") { backStackEntry ->
                        val id = backStackEntry.arguments?.getString("id")
                        val players = playerViewModel.players.collectAsStateWithLifecycle().value
                        val player = players.find { it.idNumber == id }
                        RegisterPlayerScreen(navController, playerViewModel, player)
                    }
                }
            }
        }
    }
}