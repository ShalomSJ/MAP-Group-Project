package com.example.namibianhockeyapp.ui.theme



import android.widget.Toast
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.namibianhockeyapp.Data.Player
import com.example.namibianhockeyapp.viewModel.PlayerViewModel

@Composable
fun RegisterPlayerScreen(
    navController: NavController,
    playerViewModel: PlayerViewModel,
    existingPlayer: Player? = null
) {
    var fullName by remember { mutableStateOf(existingPlayer?.fullName ?: "") }
    var idNumber by remember { mutableStateOf(existingPlayer?.idNumber ?: "") }
    var dob by remember { mutableStateOf(existingPlayer?.dateOfBirth ?: "") }
    var gender by remember { mutableStateOf(existingPlayer?.gender ?: "") }
    var nationality by remember { mutableStateOf(existingPlayer?.nationality ?: "") }
    var position by remember { mutableStateOf(existingPlayer?.position ?: "") }
    var team by remember { mutableStateOf(existingPlayer?.team ?: "") }
    var email by remember { mutableStateOf(existingPlayer?.email ?: "") }
    var contactNumber by remember { mutableStateOf(existingPlayer?.contactNumber ?: "") }

    val context = LocalContext.current

    Column(
        modifier = Modifier
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        Text("Register Player", style = MaterialTheme.typography.titleLarge)
        Spacer(Modifier.height(16.dp))

        OutlinedTextField(
            value = fullName,
            onValueChange = { fullName = it },
            label = { Text("Full Name") },
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(8.dp))

        OutlinedTextField(
            value = dob,
            onValueChange = { dob = it },
            label = { Text("Date of Birth (YYYY-MM-DD)") },
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(8.dp))

        OutlinedTextField(
            value = gender,
            onValueChange = { gender = it },
            label = { Text("Gender") },
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(8.dp))

        OutlinedTextField(
            value = nationality,
            onValueChange = { nationality = it },
            label = { Text("Nationality") },
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(8.dp))

        OutlinedTextField(
            value = idNumber,
            onValueChange = { idNumber = it },
            label = { Text("ID Number") },
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(8.dp))

        OutlinedTextField(
            value = position,
            onValueChange = { position = it },
            label = { Text("Position") },
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(8.dp))

        OutlinedTextField(
            value = team,
            onValueChange = { team = it },
            label = { Text("Team") },
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(8.dp))

        OutlinedTextField(
            value = email,
            onValueChange = { email = it },
            label = { Text("Email") },
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(8.dp))

        OutlinedTextField(
            value = contactNumber,
            onValueChange = { contactNumber = it },
            label = { Text("Contact Number") },
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(16.dp))

        Button(
            onClick = {
                if (fullName.isBlank() || dob.isBlank() || gender.isBlank() ||
                    nationality.isBlank() || idNumber.isBlank() || position.isBlank() ||
                    team.isBlank() || email.isBlank() || contactNumber.isBlank()
                ) {
                    Toast.makeText(context, "Please fill in all fields", Toast.LENGTH_SHORT).show()
                    return@Button
                }

                val player = Player(
                    fullName = fullName,
                    dateOfBirth = dob,
                    gender = gender,
                    nationality = nationality,
                    idNumber = idNumber,
                    position = position,
                    team = team,
                    email = email,
                    contactNumber = contactNumber
                )

                if (existingPlayer == null) {
                    playerViewModel.addPlayer(player)
                } else {
                    playerViewModel.updatePlayer(player)
                }
                navController.popBackStack()
            },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(if (existingPlayer == null) "Register" else "Update")
        }
    }
}