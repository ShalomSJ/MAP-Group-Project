import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class TeamRegistration extends StatefulWidget {
  @override
  _TeamRegistrationState createState() => _TeamRegistrationState();
}

class _TeamRegistrationState extends State<TeamRegistration> {
  final _formKey = GlobalKey<FormState>();
  final teamNameController = TextEditingController();
  final coachNameController = TextEditingController();

  void _submitTeam() async {
    if (_formKey.currentState!.validate()) {
      try {
        await FirebaseFirestore.instance.collection('teams').add({
          'teamName': teamNameController.text.trim(),
          'coachName': coachNameController.text.trim(),
          'createdAt': Timestamp.now(),
        });

        debugPrint("✔ Team Registered to Firestore");

        final scaffold = ScaffoldMessenger.maybeOf(context);
        scaffold?.showSnackBar(SnackBar(content: Text("✅ Team Registered!")));

        _formKey.currentState!.reset();
      } catch (e) {
        debugPrint("❌ Error: $e");
        final scaffold = ScaffoldMessenger.maybeOf(context);
        scaffold?.showSnackBar(SnackBar(content: Text("Error: $e")));
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Team Registration")),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Form(
          key: _formKey,
          child: Column(
            children: [
              TextFormField(
                controller: teamNameController,
                decoration: InputDecoration(labelText: "Team Name", border: OutlineInputBorder()),
                validator: (val) => val!.isEmpty ? 'Enter team name' : null,
              ),
              SizedBox(height: 16),
              TextFormField(
                controller: coachNameController,
                decoration: InputDecoration(labelText: "Coach Name", border: OutlineInputBorder()),
                validator: (val) => val!.isEmpty ? 'Enter coach name' : null,
              ),
              SizedBox(height: 20),
              ElevatedButton(onPressed: _submitTeam, child: Text("Register Team")),
            ],
          ),
        ),
      ),
    );
  }
}
