import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class EventEntries extends StatefulWidget {
  @override
  _EventEntriesState createState() => _EventEntriesState();
}

class _EventEntriesState extends State<EventEntries> {
  final _formKey = GlobalKey<FormState>();
  final eventNameController = TextEditingController();
  final venueController = TextEditingController();
  DateTime? selectedDate;

  void _submitEvent() async {
    if (_formKey.currentState!.validate() && selectedDate != null) {
      try {
        await FirebaseFirestore.instance.collection('events').add({
          'eventName': eventNameController.text.trim(),
          'venue': venueController.text.trim(),
          'eventDate': selectedDate!.toIso8601String(),
          'createdAt': Timestamp.now(),
        });

        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text("✅ Event Created")),
        );

        _formKey.currentState!.reset();
        setState(() => selectedDate = null);
      } catch (e) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text("❌ Error: $e")),
        );
      }
    } else if (selectedDate == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("⚠ Please select a date")),
      );
    }
  }

  Future<void> _pickDate() async {
    DateTime? date = await showDatePicker(
      context: context,
      initialDate: selectedDate ?? DateTime.now(),
      firstDate: DateTime.now(),
      lastDate: DateTime(2100),
    );

    if (date != null) {
      setState(() => selectedDate = date);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Create Event")),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Form(
          key: _formKey,
          child: Column(
            children: [
              TextFormField(
                controller: eventNameController,
                decoration: InputDecoration(
                  labelText: "Event Name",
                  border: OutlineInputBorder(),
                  prefixIcon: Icon(Icons.event),
                ),
                validator: (val) => val!.isEmpty ? 'Enter event name' : null,
              ),
              SizedBox(height: 16),
              TextFormField(
                controller: venueController,
                decoration: InputDecoration(
                  labelText: "Venue",
                  border: OutlineInputBorder(),
                  prefixIcon: Icon(Icons.place),
                ),
                validator: (val) => val!.isEmpty ? 'Enter venue' : null,
              ),
              SizedBox(height: 16),
              GestureDetector(
                onTap: _pickDate,
                child: AbsorbPointer(
                  child: TextFormField(
                    decoration: InputDecoration(
                      labelText: selectedDate == null
                          ? "Select Event Date"
                          : "Event Date: ${selectedDate!.toLocal().toString().split(' ')[0]}",
                      border: OutlineInputBorder(),
                      prefixIcon: Icon(Icons.calendar_today),
                    ),
                  ),
                ),
              ),
              SizedBox(height: 24),
              ElevatedButton.icon(
                onPressed: _submitEvent,
                icon: Icon(Icons.check),
                label: Text("Submit Event"),
                style: ElevatedButton.styleFrom(
                  minimumSize: Size(double.infinity, 50),
                  textStyle: TextStyle(fontSize: 16),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
