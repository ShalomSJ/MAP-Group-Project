import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class PlayerRegistration extends StatefulWidget {
  @override
  _PlayerRegistrationState createState() => _PlayerRegistrationState();
}

class _PlayerRegistrationState extends State<PlayerRegistration> {
  final _formKey = GlobalKey<FormState>();

  // Text controllers
  final fullNameController = TextEditingController();
  final dobController = TextEditingController();
  final nationalityController = TextEditingController();
  final teamController = TextEditingController();
  final positionController = TextEditingController();
  final emailController = TextEditingController();
  final phoneController = TextEditingController();

  String selectedGender = 'Male';

  void _submitPlayer() async {
    if (_formKey.currentState!.validate()) {
      await FirebaseFirestore.instance.collection('players').add({
        'fullName': fullNameController.text.trim(),
        'dateOfBirth': dobController.text.trim(),
        'gender': selectedGender,
        'nationality': nationalityController.text.trim(),
        'team': teamController.text.trim(),
        'position': positionController.text.trim(),
        'email': emailController.text.trim(),
        'phoneNumber': phoneController.text.trim(),
        'createdAt': Timestamp.now(),
      });

      ScaffoldMessenger.of(context).showSnackBar(SnackBar(
        content: Text("Player Registered Successfully!"),
      ));

      _formKey.currentState!.reset();
      setState(() {
        selectedGender = 'Male';
      });
    }
  }

  @override
  void dispose() {
    fullNameController.dispose();
    dobController.dispose();
    nationalityController.dispose();
    teamController.dispose();
    positionController.dispose();
    emailController.dispose();
    phoneController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Player Registration")),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Form(
          key: _formKey,
          child: ListView(
            children: [
              TextFormField(
                controller: fullNameController,
                decoration: InputDecoration(labelText: 'Full Name'),
                validator: (val) => val!.isEmpty ? 'Enter full name' : null,
              ),
              SizedBox(height: 16),
              TextFormField(
                controller: dobController,
                decoration: InputDecoration(labelText: 'Date of Birth (YYYY-MM-DD)'),
                validator: (val) => val!.isEmpty ? 'Enter date of birth' : null,
              ),
              SizedBox(height: 16),
              DropdownButtonFormField<String>(
                value: selectedGender,
                items: ['Male', 'Female', 'Other'].map((String gender) {
                  return DropdownMenuItem<String>(
                    value: gender,
                    child: Text(gender),
                  );
                }).toList(),
                onChanged: (val) => setState(() => selectedGender = val!),
                decoration: InputDecoration(labelText: 'Gender'),
              ),
              SizedBox(height: 16),
              TextFormField(
                controller: nationalityController,
                decoration: InputDecoration(labelText: 'Nationality'),
                validator: (val) => val!.isEmpty ? 'Enter nationality' : null,
              ),
              SizedBox(height: 16),
              TextFormField(
                controller: teamController,
                decoration: InputDecoration(labelText: 'Team'),
                validator: (val) => val!.isEmpty ? 'Enter team name' : null,
              ),
              SizedBox(height: 16),
              TextFormField(
                controller: positionController,
                decoration: InputDecoration(labelText: 'Position'),
                validator: (val) => val!.isEmpty ? 'Enter position' : null,
              ),
              SizedBox(height: 16),
              TextFormField(
                controller: emailController,
                decoration: InputDecoration(labelText: 'Email'),
                keyboardType: TextInputType.emailAddress,
                validator: (val) => val!.isEmpty || !val.contains('@') ? 'Enter a valid email' : null,
              ),
              SizedBox(height: 16),
              TextFormField(
                controller: phoneController,
                decoration: InputDecoration(labelText: 'Phone Number'),
                keyboardType: TextInputType.phone,
                validator: (val) => val!.isEmpty ? 'Enter phone number' : null,
              ),
              SizedBox(height: 20),
              ElevatedButton(
                onPressed: _submitPlayer,
                child: Text('Register Player'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
