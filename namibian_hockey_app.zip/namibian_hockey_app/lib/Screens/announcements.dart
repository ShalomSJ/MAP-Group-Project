import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class Announcements extends StatefulWidget {
  @override
  _AnnouncementsState createState() => _AnnouncementsState();
}

class _AnnouncementsState extends State<Announcements> {
  final _formKey = GlobalKey<FormState>();
  final _messageController = TextEditingController();
  bool _isSubmitting = false;

  Future<void> _postAnnouncement() async {
    if (_formKey.currentState!.validate()) {
      try {
        setState(() => _isSubmitting = true);
        await FirebaseFirestore.instance.collection('announcements').add({
          'message': _messageController.text.trim(),
          'timestamp': FieldValue.serverTimestamp(),
        });
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text("✅ Announcement posted")),
        );
        _messageController.clear();
      } catch (e) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text("❌ Error: $e")),
        );
      } finally {
        setState(() => _isSubmitting = false);
      }
    }
  }

  Widget _buildAnnouncementCard(DocumentSnapshot doc) {
    final data = doc.data() as Map<String, dynamic>;
    final timestamp = data['timestamp'] as Timestamp?;
    final formattedTime = timestamp != null
        ? DateTime.fromMillisecondsSinceEpoch(timestamp.millisecondsSinceEpoch).toLocal().toString().split('.')[0]
        : 'Pending...';
    return Card(
      margin: EdgeInsets.symmetric(horizontal: 16, vertical: 6),
      elevation: 2,
      child: ListTile(
        leading: Icon(Icons.campaign, color: Colors.green),
        title: Text(data['message'], style: TextStyle(fontWeight: FontWeight.bold)),
        subtitle: Text("Posted on: $formattedTime"),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Announcements")),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(16),
            child: Form(
              key: _formKey,
              child: Column(
                children: [
                  TextFormField(
                    controller: _messageController,
                    maxLines: 3,
                    decoration: InputDecoration(
                      labelText: "Write an announcement",
                      border: OutlineInputBorder(),
                      prefixIcon: Icon(Icons.edit),
                    ),
                    validator: (val) => val!.trim().isEmpty ? 'Please enter a message' : null,
                  ),
                  SizedBox(height: 12),
                  ElevatedButton.icon(
                    onPressed: _isSubmitting ? null : _postAnnouncement,
                    icon: Icon(Icons.send),
                    label: Text("Post"),
                    style: ElevatedButton.styleFrom(
                      minimumSize: Size(double.infinity, 50),
                    ),
                  ),
                ],
              ),
            ),
          ),
          Divider(),
          Expanded(
            child: StreamBuilder<QuerySnapshot>(
              stream: FirebaseFirestore.instance
                  .collection('announcements')
                  .orderBy('timestamp', descending: true)
                  .snapshots(),
              builder: (context, snapshot) {
                if (!snapshot.hasData) return Center(child: CircularProgressIndicator());
                if (snapshot.data!.docs.isEmpty) {
                  return Center(child: Text("No announcements yet."));
                }
                return ListView(
                  children: snapshot.data!.docs.map(_buildAnnouncementCard).toList(),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
