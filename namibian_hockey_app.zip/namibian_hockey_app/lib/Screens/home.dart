import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:namibian_hockey_app/Screens/view_event.dart';
import 'package:namibian_hockey_app/Screens/view_player.dart';
import 'package:namibian_hockey_app/Screens/view_team.dart';
import 'team_registration.dart';
import 'player_registration.dart';
import 'events.dart';
import 'announcements.dart';

class HomeScreen extends StatelessWidget {
  final Color primaryColor = Colors.green;

  Widget buildCard(BuildContext context, String title, IconData icon, Widget screen) {
    return Card(
      elevation: 3,
      margin: const EdgeInsets.symmetric(vertical: 8, horizontal: 16),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      child: ListTile(
        leading: Icon(icon, color: primaryColor),
        title: Text(title, style: TextStyle(fontWeight: FontWeight.bold)),
        trailing: Icon(Icons.arrow_forward_ios, size: 16),
        onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => screen)),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Namibia Hockey Union"),
        actions: [
          IconButton(
            icon: Icon(Icons.logout),
            onPressed: () => FirebaseAuth.instance.signOut(),
          ),
        ],
      ),
      body: ListView(
        children: [
          SizedBox(height: 16),
          Center(
            child: Text(
              "Welcome!",
              style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
            ),
          ),
          SizedBox(height: 8),
          buildCard(context, "Register a Team", Icons.group_add, TeamRegistration()),
          buildCard(context, "Register a Player", Icons.person_add_alt_1, PlayerRegistration()),
          buildCard(context, "Create/View Events", Icons.event, EventEntries()),
          buildCard(context, "Announcements", Icons.campaign, Announcements()),
          Divider(indent: 16, endIndent: 16, thickness: 1.2),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            child: Text("View Records", style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
          ),
          buildCard(context, "View Players", Icons.people_outline, ViewPlayers()),
          buildCard(context, "View Teams", Icons.groups, ViewTeams()),
          buildCard(context, "View Events", Icons.view_list, ViewEvents()),
          SizedBox(height: 16),
        ],
      ),
    );
  }
}
