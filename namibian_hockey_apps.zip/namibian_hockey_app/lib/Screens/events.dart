import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class EventEntries extends StatefulWidget {
  @override
  _EventEntriesState createState() => _EventEntriesState();
}

class _EventEntriesState extends State<EventEntries> {
  final _formKey = GlobalKey<FormState>();

  final eventNameController = TextEditingController();
  final descriptionController = TextEditingController();
  final venueController = TextEditingController();
  final participantsController = TextEditingController();
  final contactInfoController = TextEditingController();

  DateTime? selectedDateTime;

  void _submitEvent() async {
    if (_formKey.currentState!.validate() && selectedDateTime != null) {
      try {
        await FirebaseFirestore.instance.collection('events').add({
          'eventName': eventNameController.text.trim(),
          'description': descriptionController.text.trim(),
          'venue': venueController.text.trim(),
          'participants': participantsController.text.trim(),
          'contactInfo': contactInfoController.text.trim(),
          'eventDateTime': selectedDateTime!.toIso8601String(),
          'createdAt': Timestamp.now(),
        });

        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text("✅ Event created successfully!"),
            backgroundColor: Colors.green,
          ),
        );

        _formKey.currentState!.reset();
        eventNameController.clear();
        descriptionController.clear();
        venueController.clear();
        participantsController.clear();
        contactInfoController.clear();
        setState(() => selectedDateTime = null);
      } catch (e) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text("❌ Error: $e"),
            backgroundColor: Colors.red,
          ),
        );
      }
    } else if (selectedDateTime == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text("⚠ Please select date and time"),
          backgroundColor: Colors.orange,
        ),
      );
    }
  }

  Future<void> _pickDateTime() async {
    final date = await showDatePicker(
      context: context,
      initialDate: selectedDateTime ?? DateTime.now(),
      firstDate: DateTime.now(),
      lastDate: DateTime(2100),
    );

    if (date == null) return;

    final time = await showTimePicker(
      context: context,
      initialTime: selectedDateTime != null
          ? TimeOfDay.fromDateTime(selectedDateTime!)
          : TimeOfDay.now(),
    );

    if (time == null) return;

    setState(() {
      selectedDateTime = DateTime(
        date.year,
        date.month,
        date.day,
        time.hour,
        time.minute,
      );
    });
  }

  @override
  void dispose() {
    eventNameController.dispose();
    descriptionController.dispose();
    venueController.dispose();
    participantsController.dispose();
    contactInfoController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Create Event")),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              TextFormField(
                controller: eventNameController,
                decoration: InputDecoration(
                  labelText: "Event Name",
                  border: OutlineInputBorder(),
                  prefixIcon: Icon(Icons.event),
                ),
                validator: (val) => val!.isEmpty ? 'Enter event name' : null,
              ),
              SizedBox(height: 16),
              TextFormField(
                controller: descriptionController,
                decoration: InputDecoration(
                  labelText: "Description",
                  border: OutlineInputBorder(),
                  prefixIcon: Icon(Icons.description),
                ),
                maxLines: 3,
              ),
              SizedBox(height: 16),
              TextFormField(
                controller: venueController,
                decoration: InputDecoration(
                  labelText: "Venue",
                  border: OutlineInputBorder(),
                  prefixIcon: Icon(Icons.place),
                ),
                validator: (val) => val!.isEmpty ? 'Enter venue' : null,
              ),
              SizedBox(height: 16),
              GestureDetector(
                onTap: _pickDateTime,
                child: AbsorbPointer(
                  child: TextFormField(
                    decoration: InputDecoration(
                      labelText: selectedDateTime == null
                          ? "Select Event Date & Time"
                          : "Event Date & Time: ${_formatDateTime(selectedDateTime!)}",
                      border: OutlineInputBorder(),
                      prefixIcon: Icon(Icons.calendar_today),
                    ),
                  ),
                ),
              ),
              SizedBox(height: 16),
              TextFormField(
                controller: participantsController,
                decoration: InputDecoration(
                  labelText: "Participants",
                  border: OutlineInputBorder(),
                  prefixIcon: Icon(Icons.group),
                ),
                validator: (val) => val!.isEmpty ? 'Enter participants' : null,
              ),
              SizedBox(height: 16),
              TextFormField(
                controller: contactInfoController,
                decoration: InputDecoration(
                  labelText: "Contact Info",
                  border: OutlineInputBorder(),
                  prefixIcon: Icon(Icons.contact_phone),
                ),
                validator: (val) => val!.isEmpty ? 'Enter contact info' : null,
              ),
              SizedBox(height: 24),
              ElevatedButton.icon(
                onPressed: _submitEvent,
                icon: Icon(Icons.check),
                label: Text("Submit Event"),
                style: ElevatedButton.styleFrom(
                  minimumSize: Size(double.infinity, 50),
                  textStyle: TextStyle(fontSize: 16),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  String _formatDateTime(DateTime dateTime) {
    return "${dateTime.year}-${dateTime.month.toString().padLeft(2,'0')}-${dateTime.day.toString().padLeft(2,'0')} "
        "${dateTime.hour.toString().padLeft(2,'0')}:${dateTime.minute.toString().padLeft(2,'0')}";
  }
}
