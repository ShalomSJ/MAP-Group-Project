import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class TeamRegistration extends StatefulWidget {
  @override
  _TeamRegistrationState createState() => _TeamRegistrationState();
}

class _TeamRegistrationState extends State<TeamRegistration> {
  final _formKey = GlobalKey<FormState>();
  final teamNameController = TextEditingController();
  final coachNameController = TextEditingController();

  void _submitTeam() async {
    if (_formKey.currentState!.validate()) {
      try {
        await FirebaseFirestore.instance.collection('teams').add({
          'teamName': teamNameController.text.trim(),
          'coachName': coachNameController.text.trim(),
          'createdAt': Timestamp.now(),
        });

        debugPrint("✔ Team Registered to Firestore");

        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text("✅ Team Registered Successfully!"),
            backgroundColor: Colors.green,
          ),
        );

        _formKey.currentState!.reset();
      } catch (e) {
        debugPrint("❌ Error: $e");

        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text("❌ Failed to register team: $e"),
            backgroundColor: Colors.red,
          ),
        );
      }
    }
  }

  @override
  void dispose() {
    teamNameController.dispose();
    coachNameController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Team Registration")),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              TextFormField(
                controller: teamNameController,
                decoration: InputDecoration(
                  labelText: "Team Name",
                  border: OutlineInputBorder(),
                ),
                validator: (val) => val!.isEmpty ? 'Enter team name' : null,
              ),
              SizedBox(height: 16),
              TextFormField(
                controller: coachNameController,
                decoration: InputDecoration(
                  labelText: "Coach Name",
                  border: OutlineInputBorder(),
                ),
                validator: (val) => val!.isEmpty ? 'Enter coach name' : null,
              ),
              SizedBox(height: 24),
              ElevatedButton.icon(
                icon: Icon(Icons.group_add),
                label: Text("Register Team"),
                onPressed: _submitTeam,
              ),
            ],
          ),
        ),
      ),
    );
  }
}
