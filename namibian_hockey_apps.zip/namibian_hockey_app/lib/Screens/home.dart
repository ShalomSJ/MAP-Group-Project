import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';

import 'package:namibian_hockey_app/Screens/view_event.dart';
import 'package:namibian_hockey_app/Screens/view_player.dart';
import 'package:namibian_hockey_app/Screens/view_team.dart';
import 'team_registration.dart';
import 'player_registration.dart';
import 'events.dart';
import 'announcements.dart';

class HomeScreen extends StatefulWidget {
  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final Color primaryColor = Colors.green;

  int _selectedIndex = 0;

  final List<Widget> _bottomPages = [
    ViewTeams(),
    ViewPlayers(),
    ViewEvents(),
  ];

  Widget _buildMainContent(BuildContext context) {
    return ListView(
      padding: const EdgeInsets.symmetric(vertical: 16),
      children: [
        Center(
          child: Text(
            "Welcome to Hockey App",
            style: TextStyle(
              fontSize: 22,
              fontWeight: FontWeight.bold,
              color: primaryColor,
              shadows: [
                Shadow(
                  blurRadius: 3,
                  color: Colors.black45,
                  offset: Offset(1, 1),
                ),
              ],
            ),
          ),
        ),
        SizedBox(height: 8),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16),
          child: Text(
            "This app is designed to help manage hockey teams, players, and events across Namibia.",
            textAlign: TextAlign.center,
            style: TextStyle(
              fontSize: 14,
              shadows: [
                Shadow(
                  blurRadius: 2,
                  color: Colors.black26,
                  offset: Offset(1, 1),
                ),
              ],
            ),
          ),
        ),
        SizedBox(height: 20),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 12),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              Expanded(
                child: ElevatedButton.icon(
                  icon: Icon(Icons.group_add),
                  label: Text(" Register Team"),
                  onPressed: () => Navigator.push(
                    context,
                    MaterialPageRoute(builder: (_) => TeamRegistration()),
                  ),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: primaryColor,
                    padding: EdgeInsets.symmetric(vertical: 12),
                  ),
                ),
              ),
              SizedBox(width: 8),
              Expanded(
                child: ElevatedButton.icon(
                  icon: Icon(Icons.person_add_alt_1),
                  label: Text("Register Player"),
                  onPressed: () => Navigator.push(
                    context,
                    MaterialPageRoute(builder: (_) => PlayerRegistration()),
                  ),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: primaryColor,
                    padding: EdgeInsets.symmetric(vertical: 12),
                  ),
                ),
              ),
              SizedBox(width: 8),
              Expanded(
                child: ElevatedButton.icon(
                  icon: Icon(Icons.event),
                  label: Text("Events Entry"),
                  onPressed: () => Navigator.push(
                    context,
                    MaterialPageRoute(builder: (_) => EventEntries()),
                  ),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: primaryColor,
                    padding: EdgeInsets.symmetric(vertical: 12),
                  ),
                ),
              ),
            ],
          ),
        ),
        SizedBox(height: 16),

        // Announcements card
        buildCard(context, "Announcements", Icons.campaign, Announcements()),

        // Goal of the Namibia Hockey App
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
          child: Text(
            " Goal of the Namibia Hockey App:\n"
                "To streamline the management and development of hockey in Namibia by providing a centralized platform for registering teams and players, managing events, and sharing important announcements.",
            style: TextStyle(
              fontSize: 14,
              color: Colors.black87,
              shadows: [
                Shadow(
                  blurRadius: 2,
                  color: Colors.black26,
                  offset: Offset(1, 1),
                ),
              ],
            ),
            textAlign: TextAlign.center,
          ),
        ),
      ],
    );
  }

  Widget buildCard(BuildContext context, String title, IconData icon, Widget screen) {
    return Card(
      elevation: 3,
      margin: const EdgeInsets.symmetric(vertical: 8, horizontal: 16),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      child: ListTile(
        leading: Icon(icon, color: primaryColor),
        title: Text(title, style: TextStyle(fontWeight: FontWeight.bold)),
        trailing: Icon(Icons.arrow_forward_ios, size: 16),
        onTap: () => Navigator.push(
          context,
          MaterialPageRoute(builder: (_) => screen),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: primaryColor,
        title: Text("Namibia Hockey Union"),
        actions: [
          IconButton(
            icon: Icon(Icons.logout),
            onPressed: () => FirebaseAuth.instance.signOut(),
          ),
        ],
      ),
      body: _selectedIndex == 0
          ? Stack(
        children: [
          Positioned.fill(
            child: Image.asset(
              'assets/image/hockey.jpg',
              fit: BoxFit.cover,
            ),
          ),
          Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [
                  Colors.white.withOpacity(0.6),
                  Colors.white.withOpacity(0.0),
                ],
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
              ),
            ),
            child: _buildMainContent(context),
          ),
        ],
      )
          : _bottomPages[_selectedIndex - 1],
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _selectedIndex,
        selectedItemColor: primaryColor,
        unselectedItemColor: primaryColor,
        onTap: (index) {
          setState(() {
            _selectedIndex = index;
          });
        },
        items: const [
          BottomNavigationBarItem(
            icon: Icon(Icons.home),
            label: "Home",
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.groups),
            label: "Teams",
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.person),
            label: "Players",
          ),
          BottomNavigationBarItem(
            icon: Icon(Icons.event),
            label: "Events",
          ),
        ],
      ),
    );
  }
}
