import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class ViewPlayers extends StatelessWidget {
  void _deletePlayer(String docId, BuildContext context) async {
    try {
      await FirebaseFirestore.instance.collection('players').doc(docId).delete();
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("✅ Player deleted")),
      );
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("❌ Error: $e")),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("All Registered Players")),
      body: StreamBuilder<QuerySnapshot>(
        stream: FirebaseFirestore.instance
            .collection('players')
            .orderBy('fullName')
            .snapshots(),
        builder: (context, snapshot) {
          if (!snapshot.hasData) return Center(child: CircularProgressIndicator());

          return ListView(
            children: snapshot.data!.docs.map((doc) {
              final data = doc.data() as Map<String, dynamic>;

              // Safely extract fields with fallback
              final fullName = data['fullName'] ?? '';
              final dateOfBirth = data['dateOfBirth'] ?? '';
              final gender = data['gender'] ?? '';
              final nationality = data['nationality'] ?? '';
              final team = data['team'] ?? '';
              final position = data['position'] ?? '';
              final email = data['email'] ?? '';
              final phoneNumber = data['phoneNumber'] ?? '';

              return Card(
                margin: EdgeInsets.symmetric(horizontal: 16, vertical: 6),
                child: ListTile(
                  title: Text(fullName),
                  subtitle: Text(
                    "DOB: $dateOfBirth\n"
                        "Gender: $gender\n"
                        "Nationality: $nationality\n"
                        "Team: $team\n"
                        "Position: $position\n"
                        "Email: $email\n"
                        "Phone: $phoneNumber",
                  ),
                  isThreeLine: true,
                  trailing: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      IconButton(
                        icon: Icon(Icons.edit, color: Colors.blue),
                        onPressed: () {
                          final _fullNameController = TextEditingController(text: fullName);
                          final _dobController = TextEditingController(text: dateOfBirth);
                          final _genderController = TextEditingController(text: gender);
                          final _nationalityController = TextEditingController(text: nationality);
                          final _teamController = TextEditingController(text: team);
                          final _positionController = TextEditingController(text: position);
                          final _emailController = TextEditingController(text: email);
                          final _phoneController = TextEditingController(text: phoneNumber);

                          showDialog(
                            context: context,
                            builder: (ctx) => AlertDialog(
                              title: Text("Edit Player"),
                              content: SingleChildScrollView(
                                child: Column(
                                  mainAxisSize: MainAxisSize.min,
                                  children: [
                                    TextField(
                                      controller: _fullNameController,
                                      decoration: InputDecoration(labelText: "Full Name"),
                                    ),
                                    SizedBox(height: 16),
                                    TextField(
                                      controller: _dobController,
                                      decoration: InputDecoration(labelText: "Date of Birth"),
                                    ),
                                    SizedBox(height: 16),
                                    TextField(
                                      controller: _genderController,
                                      decoration: InputDecoration(labelText: "Gender"),
                                    ),
                                    SizedBox(height: 16),
                                    TextField(
                                      controller: _nationalityController,
                                      decoration: InputDecoration(labelText: "Nationality"),
                                    ),
                                    SizedBox(height: 16),
                                    TextField(
                                      controller: _teamController,
                                      decoration: InputDecoration(labelText: "Team"),
                                    ),
                                    SizedBox(height: 16),
                                    TextField(
                                      controller: _positionController,
                                      decoration: InputDecoration(labelText: "Position"),
                                    ),
                                    SizedBox(height: 16),
                                    TextField(
                                      controller: _emailController,
                                      decoration: InputDecoration(labelText: "Email"),
                                      keyboardType: TextInputType.emailAddress,
                                    ),
                                    SizedBox(height: 16),
                                    TextField(
                                      controller: _phoneController,
                                      decoration: InputDecoration(labelText: "Phone Number"),
                                      keyboardType: TextInputType.phone,
                                    ),
                                    SizedBox(height: 16),
                                  ],
                                ),
                              ),
                              actions: [
                                TextButton(
                                  child: Text("Cancel"),
                                  onPressed: () => Navigator.pop(ctx),
                                ),
                                TextButton(
                                  child: Text("Save"),
                                  onPressed: () async {
                                    final newFullName = _fullNameController.text.trim();
                                    final newDob = _dobController.text.trim();
                                    final newGender = _genderController.text.trim();
                                    final newNationality = _nationalityController.text.trim();
                                    final newTeam = _teamController.text.trim();
                                    final newPosition = _positionController.text.trim();
                                    final newEmail = _emailController.text.trim();
                                    final newPhone = _phoneController.text.trim();

                                    if (newFullName.isEmpty ||
                                        newDob.isEmpty ||
                                        newGender.isEmpty ||
                                        newNationality.isEmpty ||
                                        newTeam.isEmpty ||
                                        newPosition.isEmpty ||
                                        newEmail.isEmpty ||
                                        newPhone.isEmpty) {
                                      ScaffoldMessenger.of(context).showSnackBar(
                                        SnackBar(content: Text("Please fill all fields")),
                                      );
                                      return;
                                    }

                                    try {
                                      await FirebaseFirestore.instance
                                          .collection('players')
                                          .doc(doc.id)
                                          .update({
                                        'fullName': newFullName,
                                        'dateOfBirth': newDob,
                                        'gender': newGender,
                                        'nationality': newNationality,
                                        'team': newTeam,
                                        'position': newPosition,
                                        'email': newEmail,
                                        'phoneNumber': newPhone,
                                      });
                                      Navigator.pop(ctx);
                                      ScaffoldMessenger.of(context).showSnackBar(
                                        SnackBar(content: Text("✅ Player updated")),
                                      );
                                    } catch (e) {
                                      ScaffoldMessenger.of(context).showSnackBar(
                                        SnackBar(content: Text("❌ Error: $e")),
                                      );
                                    }
                                  },
                                ),
                              ],
                            ),
                          );
                        },
                      ),
                      IconButton(
                        icon: Icon(Icons.delete, color: Colors.red),
                        onPressed: () {
                          showDialog(
                            context: context,
                            builder: (ctx) => AlertDialog(
                              title: Text("Delete Player"),
                              content:
                              Text("Are you sure you want to delete '$fullName'?"),
                              actions: [
                                TextButton(
                                  child: Text("Cancel"),
                                  onPressed: () => Navigator.pop(ctx),
                                ),
                                TextButton(
                                  child: Text("Delete", style: TextStyle(color: Colors.red)),
                                  onPressed: () {
                                    Navigator.pop(ctx);
                                    _deletePlayer(doc.id, context);
                                  },
                                ),
                              ],
                            ),
                          );
                        },
                      ),
                    ],
                  ),
                ),
              );
            }).toList(),
          );
        },
      ),
    );
  }
}
