import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:intl/intl.dart';

class ViewEvents extends StatelessWidget {
  void _deleteEvent(String docId, BuildContext context) async {
    try {
      await FirebaseFirestore.instance.collection('events').doc(docId).delete();
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("✅ Event deleted")),
      );
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("❌ Error: $e")),
      );
    }
  }

  String _formatDateTime(dynamic timestampOrString) {
    DateTime? dateTime;

    if (timestampOrString == null) return 'No Date/Time';

    if (timestampOrString is Timestamp) {
      dateTime = timestampOrString.toDate();
    } else if (timestampOrString is String) {
      try {
        dateTime = DateTime.parse(timestampOrString);
      } catch (e) {
        return 'Invalid Date/Time';
      }
    } else if (timestampOrString is DateTime) {
      dateTime = timestampOrString;
    } else {
      return 'Invalid Date/Time';
    }

    return DateFormat('EEE, MMM d, yyyy • h:mm a').format(dateTime);
  }

  Future<DateTime?> _pickDateTime(BuildContext context, DateTime initialDateTime) async {
    final pickedDate = await showDatePicker(
      context: context,
      initialDate: initialDateTime,
      firstDate: DateTime(2000),
      lastDate: DateTime(2100),
    );

    if (pickedDate == null) return null;

    final pickedTime = await showTimePicker(
      context: context,
      initialTime: TimeOfDay.fromDateTime(initialDateTime),
    );

    if (pickedTime == null) return null;

    return DateTime(
      pickedDate.year,
      pickedDate.month,
      pickedDate.day,
      pickedTime.hour,
      pickedTime.minute,
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Upcoming Events")),
      body: StreamBuilder<QuerySnapshot>(
        stream: FirebaseFirestore.instance
            .collection('events')
            .orderBy('eventDateTime')
            .snapshots(),
        builder: (context, snapshot) {
          if (!snapshot.hasData) return Center(child: CircularProgressIndicator());

          if (snapshot.data!.docs.isEmpty)
            return Center(child: Text("No upcoming events."));

          return ListView(
            children: snapshot.data!.docs.map((doc) {
              final data = doc.data()! as Map<String, dynamic>;

              final eventName = data['eventName'] ?? 'Unnamed Event';
              final description = data['description'] ?? 'No Description';
              final eventDateTime = data['eventDateTime'];
              final venue = data['venue'] ?? 'No Venue';
              final participants = data['participants'] ?? 'No Participants Info';
              final contactInfo = data['contactInfo'] ?? 'No Contact Info';

              return Card(
                margin: EdgeInsets.symmetric(horizontal: 16, vertical: 6),
                child: ListTile(
                  leading: Icon(Icons.event, color: Colors.green),
                  title: Text(eventName, style: TextStyle(fontWeight: FontWeight.bold)),
                  subtitle: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      SizedBox(height: 4),
                      Text(description),
                      SizedBox(height: 6),
                      Text("Date & Time: ${_formatDateTime(eventDateTime)}"),
                      Text("Venue: $venue"),
                      Text("Participants: $participants"),
                      Text("Contact: $contactInfo"),
                    ],
                  ),
                  isThreeLine: true,
                  trailing: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      // Edit Button
                      IconButton(
                        icon: Icon(Icons.edit, color: Colors.blue),
                        onPressed: () async {
                          final _eventNameController = TextEditingController(text: eventName);
                          final _descriptionController = TextEditingController(text: description);
                          final _venueController = TextEditingController(text: venue);
                          final _participantsController = TextEditingController(text: participants);
                          final _contactInfoController = TextEditingController(text: contactInfo);
                          DateTime selectedDateTime =
                          eventDateTime is Timestamp ? eventDateTime.toDate() : DateTime.now();

                          showDialog(
                            context: context,
                            builder: (ctx) => AlertDialog(
                              title: Text("Edit Event"),
                              content: SingleChildScrollView(
                                child: Column(
                                  mainAxisSize: MainAxisSize.min,
                                  children: [
                                    TextField(
                                      controller: _eventNameController,
                                      decoration: InputDecoration(labelText: "Event Name"),
                                    ),
                                    SizedBox(height: 16),
                                    TextField(
                                      controller: _descriptionController,
                                      decoration: InputDecoration(labelText: "Description"),
                                    ),
                                    SizedBox(height: 16),
                                    TextField(
                                      controller: _venueController,
                                      decoration: InputDecoration(labelText: "Venue"),
                                    ),
                                    SizedBox(height: 16),
                                    TextField(
                                      controller: _participantsController,
                                      decoration: InputDecoration(labelText: "Participants"),
                                    ),
                                    SizedBox(height: 16),
                                    TextField(
                                      controller: _contactInfoController,
                                      decoration: InputDecoration(labelText: "Contact Info"),
                                    ),
                                    SizedBox(height: 10),
                                    Row(
                                      children: [
                                        Expanded(
                                          child: Text(
                                            "Date & Time:\n${_formatDateTime(selectedDateTime)}",
                                            style: TextStyle(fontSize: 13),
                                          ),
                                        ),
                                        IconButton(
                                          icon: Icon(Icons.calendar_today),
                                          onPressed: () async {
                                            final picked = await _pickDateTime(context, selectedDateTime);
                                            if (picked != null) {
                                              selectedDateTime = picked;
                                            }
                                          },
                                        )
                                      ],
                                    ),
                                  ],
                                ),
                              ),
                              actions: [
                                TextButton(
                                  child: Text("Cancel"),
                                  onPressed: () => Navigator.pop(ctx),
                                ),
                                TextButton(
                                  child: Text("Save"),
                                  onPressed: () async {
                                    final newName = _eventNameController.text.trim();
                                    final newDesc = _descriptionController.text.trim();
                                    final newVenue = _venueController.text.trim();
                                    final newParticipants = _participantsController.text.trim();
                                    final newContact = _contactInfoController.text.trim();

                                    if (newName.isEmpty || newDesc.isEmpty) {
                                      ScaffoldMessenger.of(context).showSnackBar(
                                        SnackBar(content: Text("Please fill required fields")),
                                      );
                                      return;
                                    }

                                    try {
                                      await FirebaseFirestore.instance.collection('events').doc(doc.id).update({
                                        'eventName': newName,
                                        'description': newDesc,
                                        'venue': newVenue,
                                        'participants': newParticipants,
                                        'contactInfo': newContact,
                                        'eventDateTime': selectedDateTime,
                                      });
                                      Navigator.pop(ctx);
                                      ScaffoldMessenger.of(context).showSnackBar(
                                        SnackBar(content: Text("✅ Event updated")),
                                      );
                                    } catch (e) {
                                      ScaffoldMessenger.of(context).showSnackBar(
                                        SnackBar(content: Text("❌ Error: $e")),
                                      );
                                    }
                                  },
                                ),
                              ],
                            ),
                          );
                        },
                      ),

                      // Delete Button
                      IconButton(
                        icon: Icon(Icons.delete, color: Colors.red),
                        onPressed: () {
                          showDialog(
                            context: context,
                            builder: (ctx) => AlertDialog(
                              title: Text("Delete Event"),
                              content: Text("Are you sure you want to delete '$eventName'?"),
                              actions: [
                                TextButton(
                                  child: Text("Cancel"),
                                  onPressed: () => Navigator.pop(ctx),
                                ),
                                TextButton(
                                  child: Text("Delete", style: TextStyle(color: Colors.red)),
                                  onPressed: () {
                                    Navigator.pop(ctx);
                                    _deleteEvent(doc.id, context);
                                  },
                                ),
                              ],
                            ),
                          );
                        },
                      ),
                    ],
                  ),
                ),
              );
            }).toList(),
          );
        },
      ),
    );
  }
}
