import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class ViewTeams extends StatelessWidget {
  void _deleteTeam(String docId, BuildContext context) async {
    try {
      await FirebaseFirestore.instance.collection('teams').doc(docId).delete();
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("✅ Team deleted")),
      );
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("❌ Error: $e")),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Registered Teams")),
      body: StreamBuilder<QuerySnapshot>(
        stream: FirebaseFirestore.instance
            .collection('teams')
            .orderBy('teamName')
            .snapshots(),
        builder: (context, snapshot) {
          if (!snapshot.hasData)
            return Center(child: CircularProgressIndicator());

          return ListView(
            children: snapshot.data!.docs.map((doc) {
              final data = doc.data() as Map<String, dynamic>;

              return Card(
                margin: EdgeInsets.symmetric(horizontal: 16, vertical: 6),
                child: ListTile(
                  title: Text(data['teamName']),
                  subtitle: Text("Coach: ${data['coachName']}"),
                  trailing: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      // Edit Button
                      IconButton(
                        icon: Icon(Icons.edit, color: Colors.blue),
                        onPressed: () {
                          final _teamNameController =
                          TextEditingController(text: data['teamName']);
                          final _coachNameController =
                          TextEditingController(text: data['coachName']);

                          showDialog(
                            context: context,
                            builder: (ctx) => AlertDialog(
                              title: Text("Edit Team"),
                              content: Column(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  TextField(
                                    controller: _teamNameController,
                                    decoration:
                                    InputDecoration(labelText: "Team Name"),
                                  ),
                                  SizedBox(height: 16),
                                  TextField(
                                    controller: _coachNameController,
                                    decoration:
                                    InputDecoration(labelText: "Coach Name"),
                                  ),
                                ],
                              ),
                              actions: [
                                TextButton(
                                  child: Text("Cancel"),
                                  onPressed: () => Navigator.pop(ctx),
                                ),
                                TextButton(
                                  child: Text("Save"),
                                  onPressed: () async {
                                    final newTeamName =
                                    _teamNameController.text.trim();
                                    final newCoachName =
                                    _coachNameController.text.trim();

                                    if (newTeamName.isEmpty ||
                                        newCoachName.isEmpty) {
                                      ScaffoldMessenger.of(context)
                                          .showSnackBar(
                                        SnackBar(
                                            content: Text(
                                                "Please fill all fields")),
                                      );
                                      return;
                                    }

                                    try {
                                      await FirebaseFirestore.instance
                                          .collection('teams')
                                          .doc(doc.id)
                                          .update({
                                        'teamName': newTeamName,
                                        'coachName': newCoachName,
                                      });
                                      Navigator.pop(ctx);
                                      ScaffoldMessenger.of(context)
                                          .showSnackBar(
                                        SnackBar(
                                            content:
                                            Text("✅ Team updated")),
                                      );
                                    } catch (e) {
                                      ScaffoldMessenger.of(context)
                                          .showSnackBar(
                                        SnackBar(
                                            content:
                                            Text("❌ Error: $e")),
                                      );
                                    }
                                  },
                                ),
                              ],
                            ),
                          );
                        },
                      ),

                      // Delete Button
                      IconButton(
                        icon: Icon(Icons.delete, color: Colors.red),
                        onPressed: () {
                          showDialog(
                            context: context,
                            builder: (ctx) => AlertDialog(
                              title: Text("Delete Team"),
                              content: Text(
                                  "Are you sure you want to delete '${data['teamName']}'?"),
                              actions: [
                                TextButton(
                                  child: Text("Cancel"),
                                  onPressed: () => Navigator.pop(ctx),
                                ),
                                TextButton(
                                  child:
                                  Text("Delete", style: TextStyle(color: Colors.red)),
                                  onPressed: () {
                                    Navigator.pop(ctx);
                                    _deleteTeam(doc.id, context);
                                  },
                                ),
                              ],
                            ),
                          );
                        },
                      ),
                    ],
                  ),
                ),
              );
            }).toList(),
          );
        },
      ),
    );
  }
}
