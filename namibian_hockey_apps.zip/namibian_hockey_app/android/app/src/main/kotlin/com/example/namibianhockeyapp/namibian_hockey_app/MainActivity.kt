package com.example.namibianhockeyapp.namibian_hockey_app

import io.flutter.embedding.android.FlutterActivity;


class MainActivity: FlutterActivity() {
}
